module.exports = {
  copyright: 'Dustin Shulz. MIT License.',
  pageTitle: 'Oops, sorry! This page cannot be displayed.',
  siteTitle: 'CPNT262-A4'
}